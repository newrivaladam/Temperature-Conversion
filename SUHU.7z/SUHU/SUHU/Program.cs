﻿using System;
//Welcome to my program,This program for temperature conversion I'll explain how this program works
namespace SUHU
{
    class Program
    {
        //This is Function for convert initial temperature to latter temperature it'll get intial temperature value and type of temperature
        static int Celsius(int a, string b)
            /* static = static function
             * int = function's data type
             * int a = initial temperature value
             * string b =  type of latter temperature
             */
        {
            int num = a;// initial temperature value
            string t = b;// type of temperature
            int num1 = 0;// latter temperature value
            switch (t)//Matching the conversion formula
            {
                case "R"://Celsius to Reaumur
                    num1 = 4 * num / 5;
                    break;
                case "F"://Celsius to Farenheit
                    num1 = 32 + (9 * num / 5);
                    break;
                case "K"://Celsius to Kelvin
                    num1 = num + 273;
                    break;

            }
            return num1; //Return latter temperature value
        }


        static int Reaumur(int a, string b)
        /* static = static function
        * int = function's data type
        * int a = initial temperature value
        * string b =  type of latter temperature
        */
        {
            int num = a;// initial temperature value
            string t = b;// type of temperature
            int num1 = 0;// latter temperature value
            switch (t)//Matching the conversion formula
            {
                case "C"://Reaumur to Celsius
                    num1 = 5 * num / 4;
                    break;
                case "F"://Reaumur to Farenheit
                    num1 = 32 + (9 * num / 4);
                    break;
                case "K"://Reaumur to Kelvin
                    num1 = (5 * num / 4) + 273;
                    break;

            }
            return num1; //Return latter temperature value
        }

        static int Farenheit(int a, string b)
        /* static = static function
        * int = function's data type
        * int a = initial temperature value
        * string b =  type of latter temperature
        */
        {
            int num = a;// initial temperature value
            string t = b;// type of temperature
            int num1 = 0;// latter temperature value
            switch (t)//Matching the conversion formula
            {
                case "C"://Farenheit to Celsius
                    num1 = 5 * (num-32) / 9;
                    break;
                case "R"://Farenheit to Reaumur
                    num1 = 4 * (num - 32) / 9;
                    break;
                case "K"://Farenheit to Kelvin
                    num1 = 32 + (9 * num / 5) + 273;
                    break;

            }
            return num1; //Return latter temperature value
        }

        static int Kelvin(int a, string b)
        /* static = static function
        * int = function's data type
        * int a = initial temperature value
        * string b =  type of latter temperature
        */
        {
            int num = a;// initial temperature value
            string t = b;// type of temperature
            int num1 = 0;// latter temperature value
            switch (t)//Matching the conversion formula
            {
                case "C"://Kelvin to Celsius
                    num1 = num - 273;
                    break;
                case "R"://Kelvin to Reaumur
                    num1 = (4 * num / 5) - 273;
                    break;
                case "F"://Kelvin to Farenheit
                    num1 = (5 * (num - 32) / 9) + 273;
                    break;

            }
            return num1; //Return latter temperature value
        }
        //in main function, purpose of switch to call the method resemble to type of initial temperature
        static void Main(string[] args)
        {
            string T1,T2;// typical  temperature 
            int num,num1;// value of temperature
            
            First:
            
            Console.WriteLine("\n Hello! WELCOME TO MY Temperature conversion Program.\n\n Select the Temperature.\n\n C for Celcius\n\n R for Reamur\n\n F for Farenheit\n\n K for Kelvin \n");
            T1 = Console.ReadLine();//initial temperature
            Console.WriteLine("\n\nSelect the Temperature you want to become \n");
            T2 = Console.ReadLine();//latter temperature
            
          
            if (T1 == T2)//if type of initial temperature and latter temperature is same
            {
                goto First;
            }

            Console.WriteLine("\n Write the value \n");
            num = Convert.ToInt32(Console.ReadLine());//value of initial temperature

            switch (T1)//calling the method according to type of initial temperature 
            {
                case "C"://Celsius to X
                    num1 = Celsius(num, T2);
                    break;
                case "R"://Reaumur to X
                    num1 = Reaumur(num, T2);
                    break;
                case "F"://Farenheit to X
                    num1 = Farenheit(num, T2);
                    break;
                case "K"://Kelvin to X
                    num1 = Kelvin(num, T2);
                    break;
                default:
                    goto First;

            }
           
            Console.WriteLine("\n {0} {1} = {2} {3}", num, T1, num1, T2);//Show the Result
            
            Second:
            
            Console.WriteLine("\n Continue ?(y/n)");//Asking if you want to start again
            var choisce = Console.ReadLine();
            


            if (choisce == "y")//starting again
            {
                goto First;
            }
            
            else if (choisce != "n")
            {
                goto Second;
            }
        
        

            

        }
   
    }
}
